
// A1 
console.log("DOM lab ready");

// A2 
const title = document.getElementById("title");
const firstItem = document.querySelector("#menu-list li");
const links = document.querySelectorAll(".nav-link");
const menuList = document.getElementById("menu-list");
const message = document.getElementById("message");
const tagline = document.querySelector(".tagline");
const nameInput = document.getElementById("name-input");
const hoursHeading = document.getElementById("hours");

console.log(title);
console.log(firstItem);
console.log(links);

// A3 
// task1
title.textContent = "Lagoon Café · Open now";

// task2
tagline.textContent = "Fresh food by the Batticaloa lagoon - Open now!";

// task3
message.innerHTML = "<strong>Welcome!</strong> Try our special Crab curry today.";

// task4
const menuItemsA3 = document.querySelectorAll("#menu-list li");
menuItemsA3.forEach(function(item, index) {
  item.textContent = (index + 1) + ". " + item.textContent;
});

// task5
console.log("Name input value: " + nameInput.value);

//  A4 
// task1
const special = document.querySelector(".special");
special.classList.add("highlight");

// task2
const firstLink = document.querySelector(".nav-link");
firstLink.classList.add("active");

// task3
nameInput.placeholder = "Enter your name here";

// task4
hoursHeading.style.color = "crimson";

// task5
console.log("Special item: " + special.textContent);

// A5
// task1
const newLi = document.createElement("li");
newLi.textContent = "Egg hoppers";
newLi.classList.add("item");
menuList.appendChild(newLi);

// task2
const main = document.querySelector("main");

const drinksHeading = document.createElement("h2");
drinksHeading.textContent = "Drinks";
main.appendChild(drinksHeading);

// task3
const drinksList = document.createElement("ul");
drinksList.id = "drinks-list";
main.append(drinksList);

const drinks = ["Faluda", "King coconut", "Plain tea"];
drinks.forEach(function(drink) {
  const drinkLi = document.createElement("li");
  drinkLi.textContent = drink;
  drinkLi.classList.add("item");
  drinksList.append(drinkLi);
});

// task4
const allItems = document.querySelectorAll("#menu-list li");
allItems.forEach(function(item) {
  if (item.textContent.includes("Kottu")) {
    item.remove();
  }
});

