const taskForm = document.getElementById("task-form");
const taskInput = document.getElementById("task-input");
const taskList = document.getElementById("task-list");
const clearAllBtn = document.getElementById("clear-all");
const emptyMsg = document.getElementById("empty-msg");
const taskCount = document.getElementById("task-count");

let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

function renderTasks() {
  taskList.innerHTML = "";

  tasks.forEach(function(task, index) {
    const li = document.createElement("li");
    li.textContent = task.text;
    li.classList.add("item");
    if (task.done) li.classList.add("done");

    const doneBtn = document.createElement("button");
    doneBtn.textContent = task.done ? "Undo" : "Done";
    doneBtn.classList.add("done-btn");

    const delBtn = document.createElement("button");
    delBtn.textContent = "Delete";
    delBtn.classList.add("delete-btn");

    li.append(doneBtn);
    li.append(delBtn);
    taskList.append(li);

    doneBtn.addEventListener("click", function() {
      tasks[index].done = !tasks[index].done;
      saveTasks();
      renderTasks();
    });

    delBtn.addEventListener("click", function() {
      const ok = confirm("Are you sure you want to delete this task?");
      if (ok) {
        tasks.splice(index, 1);
        saveTasks();
        renderTasks();
      }
    });
  });

  if (tasks.length === 0) {
    emptyMsg.style.display = "block";
  } else {
    emptyMsg.style.display = "none";
  }
  taskCount.textContent = tasks.length + " tasks";
}

taskForm.addEventListener("submit", function(e) {
  e.preventDefault();
  const text = taskInput.value.trim();
  if (text === "") {
    alert("Please enter a task!");
    return;
  }
  tasks.push({ text: text, done: false });
  saveTasks();
  renderTasks();
  taskInput.value = "";
  taskInput.focus();
});

clearAllBtn.addEventListener("click", function() {
  const ok = confirm("Are you sure you want to clear all tasks?");
  if (ok) {
    tasks = [];
    saveTasks();
    renderTasks();
  }
});

renderTasks();