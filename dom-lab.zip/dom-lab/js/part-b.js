
// B1
const greetBtn = document.getElementById("greet-btn");
const message = document.getElementById("message");
const themeBtn = document.getElementById("theme-btn");
const title = document.getElementById("title");

greetBtn.addEventListener("click", function() {
  message.textContent = "Hello! Welcome to Lagoon Café.";
});

// 
themeBtn.addEventListener("click", function() {
  document.body.classList.toggle("dark-mode");
  if (document.body.classList.contains("dark-mode")) {
    themeBtn.textContent = "Light mode";
  } else {
    themeBtn.textContent = "Dark mode";
  }
});

// 
let titleClicks = 0;
title.addEventListener("click", function() {
  titleClicks = titleClicks + 1;
  message.textContent = "Title clicked " + titleClicks + " times!";
});

//  B2
const nameBox = document.getElementById("name-input");
const preview = document.getElementById("preview");
const counter = document.getElementById("counter");

nameBox.addEventListener("input", function() {
  if (nameBox.value.trim() === "") {
    preview.textContent = "";
  } else {
    preview.textContent = "Hello, " + nameBox.value + "!";
  }

  counter.textContent = nameBox.value.length + " / 20";

  // 
  if (nameBox.value.length > 20) {
    counter.classList.add("over-limit");
  } else {
    counter.classList.remove("over-limit");
  }
});

//  B3 
nameBox.addEventListener("keydown", function(e) {
  console.log(e.key);

  if (e.key === "Enter") {
    message.textContent = "Saved name: " + nameBox.value;
  }
});

// 
const navLinks = document.querySelectorAll(".nav-link");
navLinks.forEach(function(link) {
  link.addEventListener("click", function(e) {
    e.preventDefault();
    message.textContent = "Clicked: " + link.textContent;
  });
});

// B4 
const menuList = document.getElementById("menu-list");

menuList.addEventListener("click", function(e) {
  const item = e.target.closest("li");
  if (!item) return;
  item.classList.toggle("done");
});

// 
menuList.addEventListener("dblclick", function(e) {
  const item = e.target.closest("li");
  if (!item) return;
  item.remove();
});



